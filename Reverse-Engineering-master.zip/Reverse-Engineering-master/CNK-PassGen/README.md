<p align="center">
<a href="#"><img title="succeed" src="https://img.shields.io/badge/deobfuscating-succeed-green?colorB=%23017e40&style=for-the-badge"></a>
</p>
<p align="left">
<a href="https://github.com/hax0rtahm1d"><img title="HaX0r Tahm1d" src="https://img.shields.io/badge/By-HaX0r%20Tahm1d-blue?style=for-the-badge&logo=github"></a>
</p>
<br/><br/>

# CNK-PassGen
Hard Password Generator

![alt text](https://img.shields.io/badge/Coded-xNot_Found-blue.svg)
![alt text](https://img.shields.io/badge/Size-15.00KB-yellow.svg)
![alt text](https://img.shields.io/badge/Python-2.7-green.svg)
# Sample Image
![alt text](https://raw.githubusercontent.com/hatakecnk/hatakecnk.github.io/master/Screenshot_2019-06-11-01-02-40-443_com.termux.png)

# How To Install
```
$ pkg install git python2
$ git clone https://github.com/hatakecnk/CNK-PassGen
```

# How To Execute
```
$ cd CNK-PassGen
$ python2 cnk-passgen.py
```
