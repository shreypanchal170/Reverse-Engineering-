<p align="center">
<a href="#"><img title="succeed" src="https://img.shields.io/badge/deobfuscating-succeed-green?colorB=%23017e40&style=for-the-badge"></a>
</p>
<p align="left">
<a href="https://github.com/hax0rtahm1d"><img title="HaX0r Tahm1d" src="https://img.shields.io/badge/By-HaX0r%20Tahm1d-blue?style=for-the-badge&logo=github"></a>
</p>
<br/><br/>

# Kali Linux
------+------

Kali Linux On Android!!!

#
#
# Name     : Kali Linux
# Coder     : Sutariya Parixit
# Code       : Bash
# S.code    : 8h4i
#

#<===================>
#
# Installation Process...

1)=> cd Kali-Linux

2)=> mv -v Arm.apk /storage/sdcard

3)=> cd Kali

4)=> chmod +x kali.sh

5)=> bash kali.sh

6)=> First check your phone architecture using arm finder app in your sdcard..

7)=> than type number (if arm to type=3)

8)=> *EVERYTHING IS POSSIBLE* 
#
# Enjoy Kali On Android!!!!
