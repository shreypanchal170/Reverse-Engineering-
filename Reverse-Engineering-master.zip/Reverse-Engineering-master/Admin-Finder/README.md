<p align="center">
<a href="#"><img title="succeed" src="https://img.shields.io/badge/deobfuscating-succeed-green?colorB=%23017e40&style=for-the-badge"></a>
</p>
<p align="left">
<a href="https://github.com/hax0rtahm1d"><img title="HaX0r Tahm1d" src="https://img.shields.io/badge/By-HaX0r%20Tahm1d-blue?style=for-the-badge&logo=github"></a>
</p>
<br/><br/>

<b><h1>Website Admin Finder Tool⚡</h1><b>

<h3><b>Installation : </b></h3>
<br>

```
 pkg install python2
```
```
 git clone https://github.com/darkhunter141/Admin-Finder
```
```
 cd Admin-Finder
```
```
 python2 adminfinder.py
```
<h3><b>Copy & Paste</b></h3>

```
pkg install python2 && git clone https://github.com/darkhunter141/Admin-Finder && cd Admin-Finder && python2 adminfinder.py
```
<br>
<h3><b>📸Screenshot</b></h3>
<br>
<img src="https://raw.githubusercontent.com/darkhunter141/Admin-Finder/main/Screenshot_20210509_161312.jpg">
<br>
<h3> It Provide only for legal activities. If You Misuse it we are not responsible for this</h3>
<h3><b><i>🖥️ Contact Info </i></b></h3>
<li>  <i><a href="https://www.facebook.com/darkhunter141/">Our Facebook Page </a></i></li>
<li>  <i><a href="https://www.facebook.com/groups/428641821766559/?ref=share">Our Facebook Community</a></i></li>
<li>  <i><a href="https://youtube.com/channel/UCkSB55ezk_2vPVwoqmPVZwg">Our Youtube Channel</a></i></li>
<li>  <i><a href="https://darkhunt3r141.blogspot.com/?m=1">Our Blogsite</a></i></li>

<br>
<h3><b><i>🤠 Devolopers :</i></b></h3>
<li> <i><a href="https://www.facebook.com/ashrafiabir04">Ashrafi Abir (DarkXploit)</a></i></li>
<li>  <i><a href="https://www.facebook.com/tanvirmahamud.shariful.3">Tanvir Mahamud Shariful (DarkWlof)</a></i></li>
