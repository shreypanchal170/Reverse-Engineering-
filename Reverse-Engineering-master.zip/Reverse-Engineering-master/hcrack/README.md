<p align="center">
<a href="#"><img title="succeed" src="https://img.shields.io/badge/deobfuscating-succeed-green?colorB=%23017e40&style=for-the-badge"></a>
</p>
<p align="left">
<a href="https://github.com/hax0rtahm1d"><img title="HaX0r Tahm1d" src="https://img.shields.io/badge/By-HaX0r%20Tahm1d-blue?style=for-the-badge&logo=github"></a>
</p>
<br/><br/>

# hcrack
hop
# hop-phish
This Is Facebook Cloning And Useful Tools Purely Codded By Me.
#Commands_To_Run_This_Tool
1-pkg update && pkg upgrade
2-pkg install python && pkg install python2
3-pkg install git
4-git clone https://github.com/Hamzahash/hcrack
5-cd hop
6-python2 hcrack.py
7-Username:hamza
8-Password:1626
-------------------------------------------------------------------------------------------
Other Important Tools Will Be Installed Automatically Through Script.So Don't Worry.
If You Need Any Help You Can Contact Me On Facebook Or WhatsApp.
Facebook:www.facebook.com/muhammad.hamza1626
WhatsApp:https://wa.me/+923097992202
-------------------------------------------------------------------------------------------
This Tools Is Workable In These Platforms Or OS
1-Linux(PC)
2-Termux(Android)
3-Userland(Android)
4-ParrotOs(PC)
-------------------------------------------------------------------------------------------
Disclaimer:
1-This Github Account Or Owner Does Not Promote Any Illegal Activities.
2-This Presentation Is For Educational Purposes Only.
3-The Owner Is Not Responsible For Any Illegal Activities Or Loss.
4-Editing Of Any Part Is Allowed By Owner.You Should Have Permission From Owner To Do That.
-------------------------------------------------------------------------------------------
Owner : Muhammad Hamza
