 <p align="center">
<a href="#"><img title="succeed" src="https://img.shields.io/badge/deobfuscating-succeed-green?colorB=%23017e40&style=for-the-badge"></a>
</p>
<p align="left">
<a href="https://github.com/hax0rtahm1d"><img title="HaX0r Tahm1d" src="https://img.shields.io/badge/By-HaX0r%20Tahm1d-blue?style=for-the-badge&logo=github"></a>
</p>
<br/><br/>


<p align="left">
 <img src="https://img.shields.io/badge/MADE%20IN-BANGLADESH-green?colorA=%23ff0000&colorB=%23017e40&style=flat-square">
 </p>
 
 <p align="center">
 <a href="https://linktr.ee/Xowmik"><img src="https://i.ibb.co/nL6NFSs/Shareit-bash.png" alt="Shareit_bash" border="0" width="800"></a>
</p>
<p align="center">
  <img src="https://img.shields.io/badge/Version-1.0-green">
  <img src="https://img.shields.io/github/license/Ign0r3dH4x0r/Shareit_bash">
  <img src="https://img.shields.io/github/stars/Ign0r3dH4x0r/Shareit_bash">
  <img src="https://img.shields.io/github/issues/Ign0r3dH4x0r/Shareit_bash?color=red">
  <img src="https://img.shields.io/github/forks/Ign0r3dH4x0r/Shareit_bash?color=teal">
</p>

<p align="center">
  <img src="https://img.shields.io/badge/Author-Shayer--Mahmud--Sowmik-cyan?style=flat-square">
  <img src="https://img.shields.io/badge/Written%20In-Bash-cyan?style=flat-square">
</p>

<p align="center">SHARE FILES FROM TERMINAL DIRECTLY WITH URL.</p>


##

### MAJOR FEATURES

- EASY TO USE
- USEFUL FOR REGULAR USERS

### Installation

```
$ git clone git://github.com/Ign0r3dH4x0r/Shareit_bash.git
$ cd Shareit_bash
$ bash setup.sh
```

- Then type "shareit" to run this tool.
##

### Single Line Command
```
apt update ; apt install git ; git clone git://github.com/Ign0r3dH4x0r/Shareit_bash.git ; cd Shareit_bash ; bash setup.sh
```

## 

### >>> IF YOU'RE BENEFITED BY THIS TOOL, THEN PLEASE SUPPORT ME.

#### Screenshots
<p align="center">
  <a href="https://ibb.co/SwRHfhn"><img src="https://i.ibb.co/23gRZDt/share1.png" alt="Shareit_bash" width="300"></a>
<a href="https://ibb.co/MDZCJPR"><img src="https://i.ibb.co/hRLmT2K/share2.png" alt="Shareit_bash" width="300"></a>
</p>
