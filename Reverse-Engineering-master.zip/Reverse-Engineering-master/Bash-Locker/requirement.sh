z="
";Fz='y';Cz='apt ';Gz='upgr';Kz='inst';Mz='node';Az='clea';Jz='pkg ';Iz='-y';Bz='r';Xz='e';Ez='te -';Lz='all ';Oz='figl';Sz='npm ';Wz='scat';Dz='upda';Uz='ash-';Qz='curl';Nz='js -';Hz='ade ';Vz='obfu';Rz=' -y';Pz='et -';Tz='-g b';
eval "$Az$Bz$z$Cz$Dz$Ez$Fz$z$Cz$Gz$Hz$Iz$z$Jz$Kz$Lz$Mz$Nz$Fz$z$Cz$Kz$Lz$Oz$Pz$Fz$z$Cz$Kz$Lz$Qz$Rz$z$Sz$Kz$Lz$Tz$Uz$Vz$Wz$Xz$z$Az$Bz"
