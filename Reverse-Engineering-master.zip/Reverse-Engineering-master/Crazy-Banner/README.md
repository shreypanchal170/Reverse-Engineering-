<p align="center">
<a href="#"><img title="succeed" src="https://img.shields.io/badge/deobfuscating-succeed-green?colorB=%23017e40&style=for-the-badge"></a>
</p>
<p align="left">
<a href="https://github.com/hax0rtahm1d"><img title="HaX0r Tahm1d" src="https://img.shields.io/badge/By-HaX0r%20Tahm1d-blue?style=for-the-badge&logo=github"></a>
</p>
<br/><br/>

# Crazy Banner
#Script by Sutariya Parixit

Installation Step :

1) git clone https://github.com/Bhai4You/Crazy-Banner


2) cd Crazy-Banner


3) chmod +x requirement.sh


4) chmod +x c-banner.sh


5) bash requirement.sh


6) bash c-banner.sh


7) goto /sdcard/jkr/c-ban.sh and add Your ASCII art than save without any modification 😅


8) than Continue Processing..


9) Enter Your Banner Name


10) Done..!!!

