z="
";Vz=' xen';Cz='apt ';Ez='te -';Pz='cd $';Qz='HOME';Bz='r';Lz='open';Hz='ade ';Wz='mux.';Xz='sh';Tz='x';Kz='all ';Oz='et -';Uz='bash';Jz='inst';Mz='ssh ';Rz='cd X';Dz='upda';Iz='-y';Nz='figl';Fz='y';Az='clea';Gz='upgr';Sz='enmu';
eval "$Az$Bz$z$Cz$Dz$Ez$Fz$z$Cz$Gz$Hz$Iz$z$Cz$Jz$Kz$Lz$Mz$Iz$z$Cz$Jz$Kz$Nz$Oz$Fz$z$Az$Bz$z$Pz$Qz$z$Rz$Sz$Tz$z$Uz$Vz$Wz$Xz" 
z="
";cz='tari';hz='e[1m';dz='ya P';Iz='e[36';Yz='1mDe';Hz='t  \';Uz='e[0m';Fz=' -e ';fz='it\e';Bz='r';Wz='m"';Nz='By \';Jz='m\e[';gz='[0m\';Gz='"\t\';Zz='velo';bz='1mSu';Rz='cker';Dz='slee';Oz='e[33';Vz='\e[1';Lz='cryp';Xz='p 1';az='ped ';Ez='p 2';Mz='ted ';Sz=' Too';Pz='mBas';Cz='echo';iz='"';Tz='ls \';ez='arix';Qz='h Lo';Az='clea';Kz='1mEn';
eval "$Az$Bz$z$Cz$z$Dz$Ez$z$Cz$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz$z$Cz$z$Dz$Xz$z$Cz$Fz$Gz$Hz$Iz$Jz$Yz$Zz$az$Nz$Oz$Jz$bz$cz$dz$ez$fz$gz$hz$iz$z$Cz$z$Dz$Ez"
