# Cara Menggunakannya

apt update 

apt upgrade

pkg install git

git clone https://github.com/BLackWhite0711/Noprian

cd Noprian

chmod +x *

bash setup

./FBH

Tekan "help"

Login fb

# Kontak yang Bisa DiHubungi

 #BLackWhite Team

whatshapp : 085380067478

Youtube   : BLackWhite Team

Instagram : noprian0_0

Facebook  : Noprian

Link YT   : https://www.youtube.com/channel/UCJWgAlqKsytbWqYrYhAPWvw

Link FB   : https://www.facebook.com/drak.angle.338

Link IG   : https://www.instagram.com/noprian0_0/

