clear
apt update -y
apt upgrade -y
apt install figlet -y
apt install toilet -y
apt install nano -y
apt install ruby -y
echo
echo
figlet -f pagga Basic installation | lolcat
echo
echo
gem install lolcat
apt install php -y
apt install openssh -y
apt install termux-api php
clear
echo
echo
echo
echo -e " \e[1m\e[33m\t 	Successful Installed Required Pkg..!!!"
sleep 3
clear
echo
echo
echo -e "\e[36m\t\tNow You Can Run \e[32mbash 127.0.0.1.sh\e[0m"
echo
