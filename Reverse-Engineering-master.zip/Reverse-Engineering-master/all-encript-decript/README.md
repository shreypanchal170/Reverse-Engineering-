<p align="center">
<a href="#"><img title="succeed" src="https://img.shields.io/badge/deobfuscating-succeed-green?colorB=%23017e40&style=for-the-badge"></a>
</p>
<p align="left">
<a href="https://github.com/hax0rtahm1d"><img title="HaX0r Tahm1d" src="https://img.shields.io/badge/By-HaX0r%20Tahm1d-blue?style=for-the-badge&logo=github"></a>
</p>
<br/><br/>


## VIRUS  # DONT RUN IT !!!

# DON,T TRY TO EDIT MY SCRIPT OTHER WISE I WILL ....
# SAMAJHDAR K LIYE ESHARA HI KAFI HAI.....
# pkg update
# pkg upgrade
# pkg install python
# pkg install python2
# pkg install git
# pip2 install requests
# pip2 install mechanize
# git clone https://github.com/Mafia-Killer404/all-encript-decript.git
# ls
# cd all-encript-decript
# ls
# python2 all-encript-decript.py
