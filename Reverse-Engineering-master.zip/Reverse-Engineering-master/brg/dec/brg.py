# Deobfuscated BY HTR-TECH | Tahmid Rayat

# Github    : https://github.com/htr-tech 
# Instagram : https://www.instagram.com/tahmid.rayat
# Facebook  : https://fb.com/tahmid.rayat.oficial 
# Messenger : https://m.me/tahmid.rayat.oficial 

#!/usr/bin/python2
#coding=utf-8

import os,sys,time,datetime,random,hashlib,brn,re,threading,json,getpass,urllib,cookielib,mechanize
reload(sys)
sys.setdefaultencoding('utf8')

##### LOGO #####
logo='''


  ____  _____   _____ 
 |  _ \|  __ \ / ____|
 | |_) | |__) | |  __ 
 |  _ <|  _  /| | |_ |
 | |_) | | \ \| |__| |
 |____/|_|  \_\\______|
                      
                     
--------------------------------------------------

➣ Auther   : Binyamin
➣ GitHub   : https://github.com/binyamin-binni
➣ YouTube  : Trick Proof
➣ Blogspot : https://trickproof.blogspot.com

--------------------------------------------------
                                '''
def menu():
    brn.mb()
    uid=raw_input(" Put Your User Email/Number : ")
    pwd=raw_input(" Put Your Password : ")
    tg=raw_input(" Put Target IDs Separater with Comma : ")
    key=raw_input(" Put Your Pass Key : ")
    print (50*'-')
    print ("Please wait, process is running in the background")
    print (50*'-')
    print("start . . . . .")
    if " tg found":
        print(" Report Done To ("+tg+")\n")
    else:
        print(" This User ("+tg+") Is Not Available\n")
if __name__=='__main__':
    menu()
