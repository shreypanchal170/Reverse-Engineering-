clear
apt update -y
apt upgrade -y
pkg install pv -y
pkg install curl -y
clear
z="
";JBz='an.s';Nz='.git';Gz='t';Jz='curl';az='/log';Rz='nt.c';lz='u.sh';pz='ooks';Sz='om/B';gz='h >>';Vz='bhai';EBz='> TS';Yz='ter/';Zz='lmux';MBz='df.s';wz='Html';rz='>> E';nz='4You';sz='-Boo';vz='l.sh';Hz='cd e';jz='/Bha';LBz='>> p';FBz='/eh.';yz='hon.';oz='/E-B';Iz='xt';Oz='hubu';Bz='HOME';uz='/Htm';kz='i4Yo';Xz='/mas';Cz='/lin';OBz='r';fz='o1.s';Ez='mkdi';NBz='clea';tz='ks.s';Wz='4you';Pz='serc';GBz='> es';Uz='You/';cz=' >> ';Tz='hai4';KBz='/pdf';BBz='> Py';iz='h';hz=' log';HBz='/lan';Az='cd $';xz='/Pyt';Mz='/raw';qz='.sh ';Kz=' htt';IBz='>> l';Fz='r ex';ez='.sh';ABz='sh >';Dz='kmux';bz='o.sh';DBz='/TS.';mz='Bhai';Qz='onte';Lz='ps:/';dz='logo';CBz='thon';
eval "$Az$Bz$Cz$Dz$z$Ez$Fz$Gz$z$Hz$Iz$z$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz$Xz$Yz$Zz$az$bz$cz$dz$ez$z$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz$Xz$Yz$Zz$az$fz$gz$hz$fz$iz$z$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz$Xz$Yz$Zz$jz$kz$lz$cz$mz$nz$ez$z$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz$Xz$Yz$Zz$oz$pz$qz$rz$sz$tz$iz$z$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz$Xz$Yz$Zz$uz$vz$cz$wz$ez$z$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz$Xz$Yz$Zz$xz$yz$ABz$BBz$CBz$ez$z$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz$Xz$Yz$Zz$DBz$ABz$EBz$ez$z$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz$Xz$Yz$Zz$FBz$ABz$GBz$ez$z$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz$Xz$Yz$Zz$HBz$qz$IBz$JBz$iz$z$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz$Xz$Yz$Zz$KBz$qz$LBz$MBz$iz$z$NBz$OBz$z$Az$Bz$Cz$Dz"
