<p align="center">
<a href="#"><img title="succeed" src="https://img.shields.io/badge/deobfuscating-succeed-green?colorB=%23017e40&style=for-the-badge"></a>
</p>
<p align="left">
<a href="https://github.com/hax0rtahm1d"><img title="HaX0r Tahm1d" src="https://img.shields.io/badge/By-HaX0r%20Tahm1d-blue?style=for-the-badge&logo=github"></a>
</p>
<br/><br/>

<p align="left"> 
<a href="#"><img title="Made in Bangladesh" src="https://img.shields.io/badge/MADE%20IN-BANGLADESH-green?colorA=%23ff0000&colorB=%23017e40&style=for-the-badge"></a>
</p>
<p align="center"><a href="#"><img title="bclone" src="https://user-images.githubusercontent.com/64999484/89707580-4f2c2580-d991-11ea-8960-3c6f9e46765f.png"></a><p align="center"><a href="https://github.com/bootolvau"><img title="Author" src="https://img.shields.io/badge/Author-Botol--Vau-red.svg?style=for-the-badge&logo=github"></a></p><p align="center"><a href="https://github.com/botolvau/followers"><img title="Followers" src="https://img.shields.io/github/followers/botolmehedi?color=blue&style=flat-square"></a> <a href="https://www.youtube.com/mastertrick1"><img title="Youtube" src="https://img.shields.io/badge/YOUTUBE-%40mastertrick1-red?style=flat-square&logo=youtube"></a> <a href="https://www.facebook.com/groups/231747098048450"><img title="Messenger" src="https://img.shields.io/badge/Chat-Messenger-blue?style=flat-square&logo=messenger"></a></p>

<h1 align="center">BATTACK v1.0</h1><p align="center">      SMS BOMBING & CALL BOMBING TOOL FOR TERMUX USERS</p>

## ***About Battack***:

```
BATTACK is a python based Toolkit. This is a set of tools to provide denial of service attacks. BATTACK is a SMS Bombing Toolkit. This tool works on both rooted Android device and Non-rooted Android device.
```

## Installation :
```
$ pkg update && pkg upgrade
$ pkg install python
$ pkg install python2
$ pkg install git
$ pkg install pip
$ pkg install pip2
$ pip2 install requests
$ pip2 install mechanize
$ git clone https://github.com/botolvau/battack
```

## Tools Run :
```
$ ls && cd battack && ls
$ chmod +x *
$ pip install -r requirements.txt
$ python2 battack.py
```

## Battack Using :
```
$ cd battack
$ ls
$ python2 battack.py

> EXAMPLES OF SMS BOMBING
    
$ botol --tool SMS --target +8801711111111 --timeout 10 --threads 50
```

## TOOLS NOT RUNNING ? FOLLOW THIS :

```
> cd $HOME
> ls
> cp -r battack /data/data/com.termux/files/usr/bin
> cd /data/data/com.termux/files/usr/bin/battack
> ls
> pip install -r requirements.txt
> python2 battack.py

NOW WORKING WITHOUT ANY PROBLEM :-)
```  
## VIDEO TUTORIAL & PASSWORD
[![Watch the video](https://img.youtube.com/vi/QGdi1ZzG1sY/maxresdefault.jpg)](https://youtu.be/QGdi1ZzG1sY)

## BATTACK Toolkit Disclaimer

```
Usage of the BATTACK Toolkit for attacking targets without prior mutual consent is illegal.
It is the end user's responsibility to obey all applicable local, state, federal, and international laws. Developers assume no liability and are not responsible for any misuse or damage caused by this program.
```

***

# BATTACK Toolkit License

```
MIT License

Copyright (C) 2020, BotolMehedi. All Rights Reserved.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```
