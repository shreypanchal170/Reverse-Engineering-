# nenc
Python script encryter
