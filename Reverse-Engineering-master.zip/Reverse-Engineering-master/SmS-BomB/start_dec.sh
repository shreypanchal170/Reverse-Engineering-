figlet "  SmS BomB "
echo
echo -e "\e[36m\e[1m Name    \e[33m  : \e[32m SmS BomB"
echo -e "\e[36m\e[1m Code      \e[33m: \e[32m Bash / Shell"
echo -e "\e[36m\e[1m Sec.Code \e[33m : \e[32m 8h4i"
echo -e "\e[36m\e[1m Platform  \e[33m: \e[32m Termux"
echo -e "\e[36m\e[1m Coder     \e[33m: \e[32m Sutariya Parixit"
echo -e "\e[36m\e[1m Github   \e[33m : \e[32m github.com/Bhai4You"
echo -e "\e[36m\e[1m Youtube   \e[33m: \e[32m youtube.com/BullAnonymous"
echo -e "\e[36m\e[1m Site      \e[33m: \e[32m https://bhai4you.blogspot.com\e[0m\e[1m"
echo
echo
echo
echo -e "Enter To Continue..."
read
clear
figlet "Start        Server"
echo
echo
sleep 3
echo -e "\e[36m\e[1m..../Done !!\e[0m\e[1m"
sleep 2
clear
figlet "   SmS BomB "
echo
echo
echo -e "\e[32m\e[1m Link :\e[36m\e[1m http://localhost:8080/smsbomb.php\e[0m"
echo
cd /sdcard/php
php -S localhost:8080 -t /sdcard/php
z="
";cz='tari';hz='e[1m';dz='ya P';Iz='e[36';Yz='1mDe';Hz='t  \';Uz='e[0m';Fz=' -e ';fz='it\e';Bz='r';Wz='m"';Nz='By \';Jz='m\e[';gz='[0m\';Gz='"\t\';Zz='velo';bz='1mSu';Rz='cker';Dz='slee';Oz='e[33';Vz='\e[1';Lz='cryp';Xz='p 1';az='ped ';Ez='p 2';Mz='ted ';Sz=' Too';Pz='mBas';Cz='echo';iz='"';Tz='ls \';ez='arix';Qz='h Lo';Az='clea';Kz='1mEn';
echo "$Az$Bz$z$Cz$z$Dz$Ez$z$Cz$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz$z$Cz$z$Dz$Xz$z$Cz$Fz$Gz$Hz$Iz$Jz$Yz$Zz$az$Nz$Oz$Jz$bz$cz$dz$ez$fz$gz$hz$iz$z$Cz$z$Dz$Ez"
