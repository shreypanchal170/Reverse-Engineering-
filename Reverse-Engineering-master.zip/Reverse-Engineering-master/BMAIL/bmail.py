# -*- coding: utf-8 -*-
import os,sys,time
print
print
os.system('clear')
print('ALL PACKAGES ARE INSTALLING. PLEASE WAIT 1 OR 2 MINUTES.....')
print
print
os.system('clear')
os.system('pkg install pip && pkg install pip2')
time.sleep(1)
os.system('clear')
os.system('pip install bain')
time.sleep(1)
os.system('clear')
os.system('pip2 install bain')
time.sleep(1)
os.system('clear')
os.system("bain")
time.sleep(1)
