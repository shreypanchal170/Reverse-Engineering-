clear
apt update
apt upgrade
apt install python
apt install python2
apt install ruby
gem install lolcat
apt install termux-api
pip install requests
pip2 install requests
pip install colorama
pip2 install colorama