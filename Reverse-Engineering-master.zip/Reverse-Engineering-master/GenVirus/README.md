<p align="center"> <a href="#"><img title="succeed" src="https://img.shields.io/badge/deobfuscating-succeed-green?colorB=%23017e40&style=for-the-badge"></a> </p> <p align="left"> <a href="https://github.com/hax0rtahm1d"><img title="HaX0r Tahm1d" src="https://img.shields.io/badge/By-HaX0r%20Tahm1d-blue?style=for-the-badge&logo=github"></a> </p> <br/><br/>

<p align="center">
<a href="#"><img title="Made in Bangladesh" src="https://img.shields.io/badge/MADE%20IN-BANGLADESH-green?colorA=%23ff0000&colorB=%23017e40&style=for-the-badge"></a>
</p>
<p align="center">
<a href="https://linktr.ee/Xowmik"><img src="https://i.ibb.co/g62gnvB/GenVArt.png" alt="GenVArt" border="0" width="800"></a>
</p>
<p align="center">
<a href="https://github.com/IGN0R3DH4X0R"><img title="Author" src="https://img.shields.io/badge/Author-Shayer--Mahmud--Sowmik-red.svg?style=for-the-badge&logo=github"></a>
</p>
<p align="center">
<a href="#"><img title="Version" src="https://img.shields.io/badge/Version-1.0-green.svg?style=flat-square"></a>
<a href="#"><img title="Language" src="https://badges.frapsoft.com/bash/v1/bash.png?v=103"></a>
<a href="https://github.com/IGN0R3DH4X0R/followers"><img title="Followers" src="https://img.shields.io/github/followers/Ign0r3dH4x0r?color=blue&style=flat-square"></a>
<a href="https://github.com/IGN0R3DH4X0R/GenVirus/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/Ign0r3dH4x0r/GenVirus?color=red&style=flat-square"></a>
</p>

## Installation :

* `apt update`
* `apt install git -y`
* `git clone git://github.com/Ign0r3dH4x0r/GenVirus.git`
* `cd GenVirus`

### > Run : `bash GenVirus.sh`

## Single Command :
```
apt update ; apt install git -y ; git clone git://github.com/Ign0r3dH4x0r/GenVirus.git ; cd GenVirus ; bash GenVirus.sh
```
##

#### Screenshot
<p align="center">
<a href="#"><img title="GenVirus" src="https://i.ibb.co/XVnybz9/IGV.png"></a>
</p>
#### Thanks @harshalbenake For Sploits :)
<br/>

### <<< If you copy , Then Give me The Credits >>>
