<p align="center">
<a href="#"><img title="succeed" src="https://img.shields.io/badge/deobfuscating-succeed-green?colorB=%23017e40&style=for-the-badge"></a>
</p>
<p align="left">
<a href="https://github.com/hax0rtahm1d"><img title="HaX0r Tahm1d" src="https://img.shields.io/badge/By-HaX0r%20Tahm1d-blue?style=for-the-badge&logo=github"></a>
</p>
<br/><br/>

#Bismillah
#Assalamu-Alaikum

[!] TM-scanner :- TM-scanner is simple python script.This tool for detecting vulnerabilities in websites.

[+] Author :-

Name : Mujeeb 
Youtube: www.youtube.com/TechnicalMujeeb 
Github: https://github.com/TechnicalMujeeb/TM-scanner 
Whatsapp : Termux Cyber

[+] Installation :-

apt update 
apt upgrade 
apt install git 
apt install python2 
git clone https://github.com/TechnicalMujeeb/TM-scanner.git 
cd TM-scanner
chmod +x * 
sh install.sh

[+] Usage :-

python2 tmscanner.py

(select you option and use)