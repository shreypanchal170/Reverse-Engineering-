# BashProtector
Encrypt Your Bash Code 

![alt text](https://img.shields.io/badge/Coded-xNot_Found-blue.svg)
![alt text](https://img.shields.io/badge/Size-5.00KB-yellow.svg)
![alt text](https://img.shields.io/badge/Bash-green.svg)

# Sample Image
![alt text](https://raw.githubusercontent.com/hatakecnk/hatakecnk.github.io/master/IMG_20190705_130508.jpg)
![alt text](https://raw.githubusercontent.com/hatakecnk/hatakecnk.github.io/master/IMG_20190705_131109.jpg)

<p align="center">
<a href="#"><img title="succeed" src="https://img.shields.io/badge/deobfuscating-succeed-green?colorB=%23017e40&style=for-the-badge"></a>
</p>
<p align="left">
<a href="https://github.com/hax0rtahm1d"><img title="HaX0r Tahm1d" src="https://img.shields.io/badge/By-HaX0r%20Tahm1d-blue?style=for-the-badge&logo=github"></a>
</p>
<br/><br/>
# How To Install
```
$ pkg install git
$ git clone https://github.com/hatakecnk/BashProtector
```

# How To Execute
```
$ cd BashProtector
$ bash run.sh
```
