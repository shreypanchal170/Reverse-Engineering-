# Reverse
Alat encrypt python2

$ git clone https://github.com/Tegar-ID/Reverse
$ cd Reverse
$ python2 reverse.py
