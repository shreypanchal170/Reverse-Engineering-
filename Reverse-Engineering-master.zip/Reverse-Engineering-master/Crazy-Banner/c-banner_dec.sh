clear
figlet -f big Custom Banner | lolcat
cyan='\e[0;36m'
lightgreen='\e[1;32m'
red='\e[1;31m'
yellow='\e[1;33m'
echo -e $lightgreen "\e[1m                      3vryth1n9   15   P0551613 !!!"
echo " "
echo -e $yellow "\e[1m                         -  Sutariya Parixit "
echo " "
echo " "
sleep 3
echo " "
cd /sdcard
mkdir jkr
cd jkr
touch c-ban.sh
echo
echo " " >> c-ban.sh
echo "clear" >> c-ban.sh
echo "cat << 'EOF' " >> c-ban.sh
echo "  " >> c-ban.sh
echo
clear
echo
echo
echo
echo -e "\e[1m\e[33m\nðŸ˜ˆ Goto \e[36m/sdcard/jkr/c-ban.sh\e[33m and edit with any \e[36mtext Editor\e[33m to Add Your  \e[31mCustom Asciii \e[33m Banner\e[32m :\n\n"
echo
read bull
echo
clear
echo
echo
echo
echo -e " \e[0m\e[1m           Save \e[36m\e[1mc-ban.sh \e[0m\e[1mand Back to \e[36m\e[1mTermux app...\e[0m "
echo
read anonymous
echo
echo
sleep 5
echo
clear
echo
echo
echo
echo -e " \e[1m\e[33m\e[1mNote :\e[0m \e[1m Please Edit Your C-ban file in Sdcard than Continue This Process...!!!"
echo
read parixit
echo
echo
clear
echo
echo
echo
echo -e "\e[1m\e[32m\e[1m          3\e[0m \e[1mTime Press Enter To Continue...       "
read bhai
read for
read you
echo "  " >> c-ban.sh
echo "EOF" >> c-ban.sh
echo
cat "c-ban.sh" >> /data/data/com.termux/files/usr/etc/bash.bashrc
echo " "
echo " "
echo " "
echo -e "\e[1m\e[33m\nWhat is Your \e[31mBanner \e[33mName\e[32m :\n\n"
read varbanner
echo
echo
echo "toilet -f big ' $varbanner' -F gay | lolcat" > 84nn3r.txt
echo
cat "84nn3r.txt" >> /data/data/com.termux/files/usr/etc/bash.bashrc
