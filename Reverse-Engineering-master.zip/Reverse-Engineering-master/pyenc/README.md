<p align="center">
<a href="#"><img title="succeed" src="https://img.shields.io/badge/deobfuscating-succeed-green?colorB=%23017e40&style=for-the-badge"></a>
</p>
<p align="left">
<a href="https://github.com/hax0rtahm1d"><img title="HaX0r Tahm1d" src="https://img.shields.io/badge/By-HaX0r%20Tahm1d-blue?style=for-the-badge&logo=github"></a>
</p>
<br/><br/>

# pyenc
r<h1>AssalamuAlaikum</h1>
<p>This Is Muhammad Hamza Here</p>
<h1>Description</h1>
<p>By this tool you can encrypt/hide your codes from the eyes of copycats. This tool is compatible with Termux and Linux</p>
<h1>How To Use</h1>
<p>Simply ! Type These Below Commands In Terminal </p>
<ul>
    <li>apt update</li>
    <li>apt upgrade</li>
    <li>apt install python2</li>
    <li>apt install git</li>
    <li>git clone https://github.com/Hamzahash/pyenc</li>
    <li>cd pyenc</li>
    <li>python2 henc.py</li>
    <li>Now Give Your File Name</li>
</ul>
<h1>My Contact Links</h1>
<ul>
    <li><a href="www.facebook.com/muhammad.hamza1626">Facebook</a></li>
    <li><a href="https://muhammad.hamza365.byethost7.com">My Website</a></li>
    <li><a href="https
</ul>
<h1>Disclaimer</h1>
<p>This Tool Is For Educational Purpose Only.Iam Not Responsible For Any Kind Of Lose By This Script.Use It On Your Own Risk</p>
