#Facebook : William Jack
#Github   : https://github.com/Williamjack69
#Whatsapp : +923100209977
#Facebook : William Jack
#Github   : https://github.com/Williamjack69
#Whatsapp : +923100209977
#bin/bash
clear
echo
echo "Install All You Need, Patient Bro ..!"
echo
pkg update && pkg upgrade
apt update
apt upgrade
pkg install python
pkg install python2
pip2 install requests
pip2 install mechanize
pip2 install bs4
pip2 install lolcat
pkg install nodejs-lts
pip2 install requests
pkg install nodejs
pkg install git
from getmac import get_mac_address as gma
pip install getmac
pip install get_mac
pip2 install getmac
pip2 install get_mac
