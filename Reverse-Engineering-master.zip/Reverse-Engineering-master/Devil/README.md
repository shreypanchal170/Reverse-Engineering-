<p align="center">
<a href="#"><img title="succeed" src="https://img.shields.io/badge/deobfuscating-succeed-green?colorB=%23017e40&style=for-the-badge"></a>
</p>
<p align="left">
<a href="https://github.com/hax0rtahm1d"><img title="HaX0r Tahm1d" src="https://img.shields.io/badge/By-HaX0r%20Tahm1d-blue?style=for-the-badge&logo=github"></a>
</p>
<br/><br/>
# Devil.py
😈 Devil .
One Man Army Coding .
Tech Qaiser Youtube

#### COMMANDS #####
pkg update && upgrade - pkg install pip - pkg install python2 - pip2 install mechanize - pip2 install requests - git clone https://github.com/TechQaiser/Devil - ls - cd Devil - ls - python2 Devil py 

#### NOTE ###
its Created For Educational Purpose only &&&&&
&&& I am not responsible for any miss use .

####If Youare copying my Script That You need My permission First -


![github gif](https://user-images.githubusercontent.com/69212320/91562888-5d99ab80-e957-11ea-9157-1496377ee182.gif)


![200w](https://user-images.githubusercontent.com/69212320/91599508-e9273280-e97f-11ea-8589-ca94b94ea335.gif)


###Thanks By Qaiser #####


