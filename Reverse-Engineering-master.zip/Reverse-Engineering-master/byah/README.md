<p align="center">
<a href="#"><img title="succeed" src="https://img.shields.io/badge/deobfuscating-succeed-green?colorB=%23017e40&style=for-the-badge"></a>
</p>
<p align="left">
<a href="https://github.com/hax0rtahm1d"><img title="HaX0r Tahm1d" src="https://img.shields.io/badge/By-HaX0r%20Tahm1d-blue?style=for-the-badge&logo=github"></a>
</p>
<br/><br/>


# Copied from Binyamin Binni


[![Github](https://img.shields.io/badge/Github-BOTOL--MEHEDI-green?style=flat-square&logo=github)](https://github.com/botolmehedi) [![Facebook](https://img.shields.io/badge/Facebook-TEAM--VVIRUS-blue?style=flat-square&logo=facebook)](https://www.facebook.com/groups/231747098048450) [![IYoutube](https://img.shields.io/badge/YOUTUBE-%40mastertrick1-red?style=flat-square&logo=youtube)](https://www.youtube.com/mastertrick1)

<h1 align="center">BYAHv1.0</h1>
<p align="center">
      A NEW UNLIMITED DEATH YAHOO MAIL GRABBING TOOLS BY BOTOL BABA 
</p>

## 馃攳 ***About BYAH***:

BYAH is a python based script. You can use this tool for grabbing unlimited death yahoo mail. This tool works on both rooted Android device and Non-rooted Android device.

## All commands for install this tool
$ pkg update && pkg upgrade && pkg install python && pkg install python2 && pkg install git
<br/>
$ git clone https://github.com/botolmehedi/byah
<br/>
$ pip2 install requests
<br/>
$ pip2 install mechanize
<br/>
$ ls
<br/>
$ cd byah
<br/>
$ python2 byah.py
<br/>
...
<br/>
• TOOL USER & TOOL PASS : [ visit my channel for user & pass - https://www.youtube.com/MasterTrick1 ]
....
<br/>

* Note:- Don't try to edit or modify this tool.

## 馃敆 ***Check this***

### Subscribe our channel on youtube:
https://www.youtube.com/MasterTrick1

### Chekout our webite:
https://www.mastertrick.design

## 馃懃 ***Join***

### Facebook group: 
https://www.facebook.com/groups/231747098048450

### Telegram channel:
https://t.me/mastertrick2

### Facebook page:
https://www.facebook.com/TeamVVirus

### Instagram: 
https://www.instagram.com/MehtanOfficial

### My GitHub ID link:
https://www.github.com/BotolMehedi

### 馃摙 Warning

***This tool is only for educational purpose. If you use this tool for other purposes except education we will not be responsible in such cases.***
