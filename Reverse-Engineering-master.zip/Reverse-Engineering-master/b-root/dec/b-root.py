# Deobfuscated BY HTR-TECH | Tahmid Rayat

# Github    : https://github.com/htr-tech 
# Instagram : https://www.instagram.com/tahmid.rayat
# Facebook  : https://fb.com/tahmid.rayat.oficial 
# Messenger : https://m.me/tahmid.rayat.oficial 

import os,sys
os.system("cd /data/data/com.termux/files/home/ && pkg install wget openssl-tool proot -y && hash -r && bash /data/data/com.termux/files/home/b-root/.README.md")
