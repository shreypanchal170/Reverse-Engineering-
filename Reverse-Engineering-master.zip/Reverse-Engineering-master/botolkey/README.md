<p align="center">
<a href="#"><img title="succeed" src="https://img.shields.io/badge/deobfuscating-succeed-green?colorB=%23017e40&style=for-the-badge"></a>
</p>
<p align="left">
<a href="https://github.com/hax0rtahm1d"><img title="HaX0r Tahm1d" src="https://img.shields.io/badge/By-HaX0r%20Tahm1d-blue?style=for-the-badge&logo=github"></a>
</p>
<br/><br/>

<p align="left">

<a href="#"><img title="Made in Bangladesh" src="https://img.shields.io/badge/MADE%20IN-BANGLADESH-green?colorA=%23ff0000&colorB=%23017e40&style=for-the-badge"></a>

</p>

<p align="center">

<a href="#"><img title="BOTOLKEY" src="https://user-images.githubusercontent.com/64999484/87812536-262cdf00-c882-11ea-84f5-6d39ba4360d2.jpg"></a>
<p align="center">
<a href="https://github.com/botolmehedi"><img title="Author" src="https://img.shields.io/badge/Author-Botol--Mehedi-red.svg?style=for-the-badge&logo=github"></a>
</p>
<p align="center">
<a href="https://github.com/botolmehedi/followers"><img title="Followers" src="https://img.shields.io/github/followers/botolmehedi?color=blue&style=flat-square"></a>
<a href="https://www.youtube.com/mastertrick1"><img title="Youtube" src="https://img.shields.io/badge/YOUTUBE-%40mastertrick1-red?style=flat-square&logo=youtube"></a>
<a href="https://www.facebook.com/groups/231747098048450"><img title="Messenger" src="https://img.shields.io/badge/Chat-Messenger-blue?style=flat-square&logo=messenger"></a>
</p>
<h1 align="center">BOTOLKEY v1.0</h1>

<p align="center">

      Magic Key Adder Tool For Termux Users.

</p>

## ***About BOTOLKEY***:

BotolKey is a python based script. You can use this tool for adding magic key in your termux. This tool works on both rooted Android device and Non-rooted Android device.

## Installation :

* pkg update && pkg upgrade && pkg install python && pkg install python2 && pkg install git && pkg install pip && pkg install pip2

* pip2 install bkey

* git clone https://github.com/botolmehedi/botolkey

## Tools Run :

* ls && cd botolkey && ls

* Python2 bk.py

* Or Just Type 'bkey' press Enter

## ***Follow Me***

* Youtube : https://www.youtube.com/MasterTrick1

* Website : https://www.mastertrick.design

* Page : https://www.facebook.com/TeamVVirus

* Group : https://www.facebook.com/groups/231747098048450

* Telegram : https://t.me/mastertrick2

* Instagram : https://www.instagram.com/MehtanOfficial

* Twitter : https://www.twitter.com/botolbaba

* GitHub : https://www.github.com/BotolMehedi

### Warning

***Don't try to edit or modify this tool. This tool is only for educational purpose. If you use this tool for other purposes except education we will not be responsible in such cases.***

