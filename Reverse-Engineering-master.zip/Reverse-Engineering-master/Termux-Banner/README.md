<p align="center">
<a href="#"><img title="succeed" src="https://img.shields.io/badge/deobfuscating-succeed-green?colorB=%23017e40&style=for-the-badge"></a>
</p>
<p align="left">
<a href="https://github.com/hax0rtahm1d"><img title="HaX0r Tahm1d" src="https://img.shields.io/badge/By-HaX0r%20Tahm1d-blue?style=for-the-badge&logo=github"></a>
</p>
<br/><br/>

# Termux Banner
#Script by Parixit Sutariya

Installation Step :

1) git clone https://github.com/Bhai4You/Termux-Banner


2) cd Termux-Banner


3) chmod +x requirement.sh


4) chmod +x t-ban.sh


5) bash requirement.sh


6) bash t-ban.sh



Uninstallation Step : (Remove Logo From Termux)

1) bash remove.sh

2) Done !!!
