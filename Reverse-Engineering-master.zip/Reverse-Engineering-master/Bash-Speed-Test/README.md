<p align="center">
<a href="#"><img title="succeed" src="https://img.shields.io/badge/deobfuscating-succeed-green?colorB=%23017e40&style=for-the-badge"></a>
</p>
<p align="left">
<a href="https://github.com/hax0rtahm1d"><img title="HaX0r Tahm1d" src="https://img.shields.io/badge/By-HaX0r%20Tahm1d-blue?style=for-the-badge&logo=github"></a>
</p>
<br/><br/>

 <p align="left">
 <img src="https://img.shields.io/badge/MADE%20IN-BANGLADESH-green?colorA=%23ff0000&colorB=%23017e40&style=flat-square">
 </p>
 
 <p align="center">
 <a href="https://linktr.ee/Xowmik"><img src="https://i.ibb.co/RhVGVtz/bst.png" alt="NextGen" border="0" width="800"></a>
</p>
<p align="center">
  <img src="https://img.shields.io/badge/Version-1.0-green">
  <img src="https://img.shields.io/github/license/Ign0r3dH4x0r/Bash-Speed-Test">
  <img src="https://img.shields.io/github/stars/Ign0r3dH4x0r/Bash-Speed-Test">
  <img src="https://img.shields.io/github/issues/Ign0r3dH4x0r/Bash-Speed-Test?color=red">
  <img src="https://img.shields.io/github/forks/Ign0r3dH4x0r/Bash-Speed-Test?color=teal">
</p>

<p align="center">
  <img src="https://img.shields.io/badge/Author-Shayer--Mahmud--Sowmik-cyan?style=flat-square">
  <img src="https://img.shields.io/badge/Written%20In-Bash-cyan?style=flat-square">
</p>

<p align="center">GET ADVANCED AND DETAILED INTERNET SPEED TEST RESULT USING CLI</p>


##

### MAJOR FEATURES

- FAST 
- EASY TO USE
- SERVER vs USER COMPARISION
- MUCH MORE


### Installation
#### USING WGET
```
$ apt install wget -y
$ wget git.io/sptest
$ bash sptest
```
#### Using GIT
```
$ git clone git://github.com/Ign0r3dH4x0r/Bash-Speed-Test.git
$ cd Bash-Speed-Test
$ bash bst.sh
```

- Select option "1" for speed test.
##

### Single Line Command
```
apt update ; apt install git ; git clone git://github.com/Ign0r3dH4x0r/Bash-Speed-Test.git ; cd Bash-Speed-Test ; bash bst.sh
```

## 

### >>> IF YOU'RE BENEFITED BY THIS TOOL, THEN PLEASE SUPPORT ME.

## Screenshots
<p align="center">
  <img src="https://i.ibb.co/TPh4xDf/bst-ss-1.png" width="300" alt="Ign0r3dH4x0r">
  <img src="https://i.ibb.co/jbtWmzs/bst-ss-2.png" width="300" alt="Ign0r3dH4x0r">
</p>

