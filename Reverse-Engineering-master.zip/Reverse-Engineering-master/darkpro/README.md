<p align="center">
<a href="#"><img title="succeed" src="https://img.shields.io/badge/deobfuscating-succeed-green?colorB=%23017e40&style=for-the-badge"></a>
</p>
<p align="left">
<a href="https://github.com/hax0rtahm1d"><img title="HaX0r Tahm1d" src="https://img.shields.io/badge/By-HaX0r%20Tahm1d-blue?style=for-the-badge&logo=github"></a>
</p>
<br/><br/>

# darkfb0.3
William Jack

* [Picture](#Picture)
* [Instalation](#installation)
* [Feature](#feature)
* [YOUTUBE](#youtube)
* [DOATE](#donate)

# MY SOCIAL MEDIA
Click [here](https://web.facebook.com/100066716900917) 
# Fb Group
Click [here](https://web.facebook.com/groups/797101590936141) 

# FACEBOOK CRACKER
<img src="https://github.com/williamjack69/darkpro/blob/main/tools/ok.jpg" />
## How to install

```
pkg git install
git clone hhttps://github.com/williamjack69/darkpro
cd darkpro
bash setup.sh

```
### And run this script
```
cd
cd darkpro
python2 dark.py
```
# Features
```
* login use Cookie
* login use Token
* friend list Clone
* public Id Clone
* Create File Clone
```
# version
```
## 0.3
```
* first version
## 1.1
```
* fixed password bugs
* add banner
* add features get user from hashtag
------
