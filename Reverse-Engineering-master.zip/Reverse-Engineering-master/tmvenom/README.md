<p align="center">
<a href="#"><img title="succeed" src="https://img.shields.io/badge/deobfuscating-succeed-green?colorB=%23017e40&style=for-the-badge"></a>
</p>
<p align="left">
<a href="https://github.com/hax0rtahm1d"><img title="HaX0r Tahm1d" src="https://img.shields.io/badge/By-HaX0r%20Tahm1d-blue?style=for-the-badge&logo=github"></a>
</p>
<br/><br/>

-----------------------------------------------------
#Bismillah
#Assalamu-Alaikum 

[!] Tmvenom :- 
  Tmvenom is a python based tool specially designed for
  Termux users.This payload generates some basic payloads
  using metasploit-framework.so You must install metasploit
  framework on your Termux.This tool works both rooted and
  non rooted devices.This is very helpfull for beginners.

[+] Requirments:-
   
   1) Termux APp
   2) metasploit-framework 
   
[+] Author :-

   Name      : Mujeeb
   Youtube   : www.youtube.com/TechnicalMujeeb
   Github    : https://github.com/TechnicalMujeeb/tmvenom.git
   Whatsapp  : Termux Cyber
   telegram  : https://t.me/TermuxCyber
   Instagram : @Technical.Mujeeb


[+] Installation :-
  
   apt update
   apt upgrade
   apt install git
   apt install python2
   git clone https://github.com/TechnicalMujeeb/tmvenom.git
   cd tmvenom
   chmod +x *
   sh install.sh

[+] Usage :-

   if you have metasploit-framework in your Termux home directory
   then you guys can use tmvenom.py

   python2 tmvenom.py

   if you dont have metasploit-framework in your termux home
   directory then you guys can run this new file, tmvenom2.py
 
   python2 tmvenom2.py

   (Now select payload options and you can easily generates payloads)

----------------------------------------------------------
